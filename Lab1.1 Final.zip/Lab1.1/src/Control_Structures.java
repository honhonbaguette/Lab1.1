public class Control_Structures
{


	public static void main(String[] args) 
	{
	
		
		lastPrimePrinter(1,100, true);

	}

	 

	public static void fooBarBaz()

	{
	
		for(int i=1; i<=500; i++)
	
		{
		
			if(i%3==0) 
		
			{
		
				System.out.print("foo");
		
			}
		
			if(i%7==0)
		
			{
		
				System.out.print("bar");
		
			}
		
			if(i%10==0)
		
			{
		
				System.out.print("baz");
		
			}
		
			if(i%3 !=0 && i%7 !=0 && i%10 !=0)
		
			{
		
				System.out.print(i);
		
			}
		
			System.out.println();
	
		}

	}

	public static void primePrinter(int x)
	{

	int numberOfPrimes = 1;

	int currentNumber =1;

	
	while(numberOfPrimes <= x)

	{

		if(isPrime(currentNumber))
	
		{
	
			if(numberOfPrimes %10 ==0 && numberOfPrimes !=0)
			{
				System.out.println(currentNumber + " ");
			}
			else 
			{
		
				System.out.print(currentNumber + " ");
		
			}
		
			numberOfPrimes++;
	
		}
	
		currentNumber++;
	
	}
	
	
	System.out.println();

	}
	
	
	public static void primePrinter(int min, int max)
	{
		System.out.println();
		
		for(int number = min; number <=max; number++)
		{		
			if(isPrime(number))
			{
				System.out.println(number + " ");
			}
		}
	}
	
	public static void lastPrimePrinter(int min, int max, boolean last)
	{
		System.out.println();
		

		for(int number = max; number >=min; number--)
		{		
			if(isPrime(number))
			{
				System.out.println(number + " ");
				break;
				
			}
			
			 
		}
	}

	 

	public static boolean isPrime(int x)

	{

		for(int i=2;i<x;i++)
	
		{
	
			if(x % i == 0)
	
			{
	
				return false;
	
			}
	
		}

	return true;

	 

	}

	 




}
